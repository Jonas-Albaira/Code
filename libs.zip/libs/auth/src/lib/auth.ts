export function auth(): string {
  return 'auth';
}
