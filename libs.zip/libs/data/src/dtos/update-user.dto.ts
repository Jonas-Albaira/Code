export class UpdateUserDto {
  name?: string;
  email?: string;
  password?: string;
  roleIds?: string[];
}
