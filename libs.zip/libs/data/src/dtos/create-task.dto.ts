export class CreateTaskDto {
  title?: string;
  description?: string;
  assignedToId?: string;
  organizationId?: string;
}
