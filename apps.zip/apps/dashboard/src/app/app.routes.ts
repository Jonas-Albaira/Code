import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'tasks' },
  { path: 'tasks', loadComponent: () => import('./tasks/tasks-page.component').then(m => m.TasksPageComponent) },
  { path: 'audit', loadComponent: () => import('./audit/audit-page.component').then(m => m.AuditPageComponent) },
  { path: 'login', loadComponent: () => import('./auth/login.component').then(m => m.LoginComponent) },
  { path: '**', redirectTo: 'tasks' },
];
