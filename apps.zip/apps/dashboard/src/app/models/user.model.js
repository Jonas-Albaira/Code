export {};
//# sourceMappingURL=user.model.js.map