import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Task } from '../models/task.model';

// @ts-ignore
@Injectable({ providedIn: 'root' })
export class TaskService {
  private base = 'http://localhost:3333/api'; // <-- API base

  constructor(private http: HttpClient) {}

  list(): Observable<Task[]> {
    return this.http.get<Task[]>(`${this.base}/tasks`);
  }

  create(task: Partial<Task>): Observable<Task> {
    return this.http.post<Task>(`${this.base}/tasks`, task);
  }

  update(id: string, task: Partial<Task>): Observable<Task> {
    return this.http.put<Task>(`${this.base}/tasks/${id}`, task);
  }

  remove(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/tasks/${id}`);
  }
}
