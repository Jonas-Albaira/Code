export const environment = {
    production: false,
    apiUrl: (typeof window !== 'undefined' && window.__API_URL__) || 'http://localhost:3333',
};
//# sourceMappingURL=environment.js.map