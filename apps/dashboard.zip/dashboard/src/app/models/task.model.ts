export type TaskStatus = 'pending' | 'in_progress' | 'completed';

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  organizationId: string;
  assignedTo?: { id: string; name: string } | string | null;
  createdAt?: string;
  updatedAt?: string;
}
