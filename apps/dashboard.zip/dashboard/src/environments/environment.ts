export const environment = {
  production: false,
  apiUrl: (typeof window !== 'undefined' && (window as any).__API_URL__) || 'http://localhost:3333',
};
